# SAS-Python
Run SAS Enterprise Guide Project Files (.egp) from Python
---------------------------------------------------------
 - Takes argument for path to project file
 - Batch Processing --> Takes multiple arguments in array
---------------------------------------------------------
<b>Command Line:</b> python SASRun.py -project "[Insert Path To Project File]"
